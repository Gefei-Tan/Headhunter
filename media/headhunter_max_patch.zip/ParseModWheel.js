var bend_amount = 0
var divider = 516
var bend_factor = 1.1
var bend_threshold = 32768 - 1500
var avail_range = 0
var ceiling = 86

function msg_int(r) {
  // r from 0 - 65535
  // mid is 32768
  // should be a curve
  // allow a +- 2000 free zone
  // not intened for precise pitch bend but more like a vibrato effect
  if (r<bend_threshold){
  // no bend
  outlet(0, 0)
}else{
  avail_range = ceiling * 516 - bend_threshold
  divider = avail_range/127
  var bend_diff = (r - bend_threshold)/divider
  //post(bend_diff)
  //if(bend_diff > )
  bend_amount = (bend_diff*bend_factor)	

  bend_amount = Math.floor(bend_amount)
  if(bend_amount > 127){
  bend_amount = 127
}else{
	// previous preset
	outlet(0, bend_amount)
  
}
  // post(bend_amount)
}
  
}