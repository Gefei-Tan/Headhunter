var bend_amount = 0
var divider = 516
var bend_factor = 0.6
var bend_threshold = 10
var change_lock = false

function msg_int(r) {
  // r from 0 - 65535
  // mid is 32768
  // should be a curve
  // allow a +- 2000 free zone
  // not intened for precise pitch bend but more like a vibrato effect
  var bend_diff = (r/divider) - 64

  if (Math.abs(bend_diff)>=bend_threshold){
  
  var bend_diff = (r/divider)
  //post(bend_diff)
  //if(bend_diff > )
  bend_amount = (bend_diff*bend_factor)	
  bend_amount = Math.floor(bend_amount)

  if(bend_diff<0){
	if(change_lock === false){
			outlet(0,29)
			change_lock = true;
}
	
}else{
	if(change_lock === false){
			outlet(0,46)
			change_lock = true;

		}


}
  // post(bend_amount)
}else{
change_lock = false;
}
  
}