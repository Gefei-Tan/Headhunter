var bend_amount = 64
var divider = 516
var bend_factor = 0.70
var bend_threshold = 3200

function msg_int(r) {
  // r from 0 - 65535
  // mid is 32768
  // should be a curve
  // allow a +- 2000 free zone
  // not intened for precise pitch bend but more like a vibrato effect
  if (Math.abs(r - 32768)<bend_threshold){
  // no bend
  outlet(0, 64)
}else{
  	
  var bend_diff = (r/divider) - 64
  bend_amount = 64 + (bend_diff*bend_factor)	
  bend_amount = Math.floor(bend_amount)
  outlet(0, bend_amount)
  // post(bend_amount)
}
  
}